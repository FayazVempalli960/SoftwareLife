"""
This module contains tests entirely maintained by Databricks. 

These tests do not rely on SQLAlchemy's custom test runner.
"""
